class ItemAlreadyStored(Exception):
    pass


class ItemNotStored(Exception):
    pass